"""
api/search.py

GET /api/search?q=<query>&type=<organism|domain|hp|keyword>&limit=20&offset=0

Searches either the local SQLite cache or triggers a UniProt fetch if needed.
"""

from flask import Blueprint, request, jsonify
from app.core.database import get_connection
from app.services.uniprot import fetch_and_cache

search_bp = Blueprint("search", __name__)

# Human-readable labels for WEKA scores
SCORE_LABELS = {
    "c1_protein_family": "Protein Family Match",
    "c2_orthology":      "Orthology",
    "c3_interaction":    "Protein Interaction",
    "c4_bbh":            "BBH (Best Bidirectional Hit)",
    "c5_sorting_signal": "Sorting Signal",
    "c6_pseudogene":     "Linked to Pseudogenes",
    "c7_homology":       "Homology Modelling",
}


@search_bp.route("/api/search", methods=["GET"])
def search():
    q      = request.args.get("q", "").strip()
    stype  = request.args.get("type", "keyword").lower()
    limit  = min(int(request.args.get("limit",  20)), 100)
    offset = max(int(request.args.get("offset",  0)),  0)

    if not q:
        return jsonify({"results": [], "total": 0, "query": q, "type": stype})

    conn = get_connection()
    try:
        if stype == "hp":
            rows, total = _search_by_hp(conn, q, limit, offset)
        elif stype == "uniprot":
            rows, total = _search_by_uniprot_id(conn, q, limit, offset)
        elif stype == "organism":
            rows, total = _search_cached(conn, q, "organism", limit, offset)
        elif stype == "domain":
            rows, total = _search_cached(conn, q, "domains", limit, offset)
        else:
            # keyword — search across organism + protein_name + domains + function
            rows, total = _search_keyword(conn, q, limit, offset)

        return jsonify({
            "results": [_format_row(r, conn) for r in rows],
            "total":   total,
            "query":   q,
            "type":    stype,
        })
    finally:
        conn.close()


def _search_by_hp(conn, q, limit, offset):
    pattern = f"%{q}%"
    sql = """
        SELECT hp.uniprot_id, hp.is_repeat, hp.related_ids, hp.uniprot_url, hp.fasta_url,
               hp.hp_label, w.hp_label AS weka_hp, w.class_label,
               w.c1_protein_family, w.c2_orthology, w.c3_interaction,
               w.c4_bbh, w.c5_sorting_signal, w.c6_pseudogene, w.c7_homology,
               uc.organism, uc.protein_name, uc.domains, uc.sequence_length
        FROM weka_scores w
        LEFT JOIN hypo_proteins hp ON hp.hp_label = w.hp_label
        LEFT JOIN uniprot_cache uc ON uc.uniprot_id = hp.uniprot_id
        WHERE w.hp_label LIKE ?
        ORDER BY w.hp_label
        LIMIT ? OFFSET ?
    """
    rows = conn.execute(sql, (pattern, limit, offset)).fetchall()
    total = conn.execute(
        "SELECT COUNT(*) FROM weka_scores WHERE hp_label LIKE ?", (pattern,)
    ).fetchone()[0]
    return rows, total


def _search_by_uniprot_id(conn, q, limit, offset):
    pattern = f"%{q}%"
    sql = """
        SELECT hp.uniprot_id, hp.is_repeat, hp.related_ids, hp.uniprot_url, hp.fasta_url,
               hp.hp_label, w.hp_label AS weka_hp, w.class_label,
               w.c1_protein_family, w.c2_orthology, w.c3_interaction,
               w.c4_bbh, w.c5_sorting_signal, w.c6_pseudogene, w.c7_homology,
               uc.organism, uc.protein_name, uc.domains, uc.sequence_length
        FROM hypo_proteins hp
        LEFT JOIN weka_scores w  ON w.hp_label  = hp.hp_label
        LEFT JOIN uniprot_cache uc ON uc.uniprot_id = hp.uniprot_id
        WHERE hp.uniprot_id LIKE ?
        ORDER BY hp.uniprot_id
        LIMIT ? OFFSET ?
    """
    rows = conn.execute(sql, (pattern, limit, offset)).fetchall()
    total = conn.execute(
        "SELECT COUNT(*) FROM hypo_proteins WHERE uniprot_id LIKE ?", (pattern,)
    ).fetchone()[0]
    return rows, total


def _search_cached(conn, q, field, limit, offset):
    """Search within the uniprot_cache table on a specific field."""
    pattern = f"%{q}%"
    sql = f"""
        SELECT hp.uniprot_id, hp.is_repeat, hp.related_ids, hp.uniprot_url, hp.fasta_url,
               hp.hp_label, w.hp_label AS weka_hp, w.class_label,
               w.c1_protein_family, w.c2_orthology, w.c3_interaction,
               w.c4_bbh, w.c5_sorting_signal, w.c6_pseudogene, w.c7_homology,
               uc.organism, uc.protein_name, uc.domains, uc.sequence_length
        FROM uniprot_cache uc
        JOIN hypo_proteins hp ON hp.uniprot_id = uc.uniprot_id
        LEFT JOIN weka_scores w ON w.hp_label = hp.hp_label
        WHERE uc.{field} LIKE ?
        ORDER BY uc.organism, hp.uniprot_id
        LIMIT ? OFFSET ?
    """
    rows = conn.execute(sql, (pattern, limit, offset)).fetchall()
    total = conn.execute(
        f"SELECT COUNT(*) FROM uniprot_cache WHERE {field} LIKE ?", (pattern,)
    ).fetchone()[0]
    return rows, total


def _search_keyword(conn, q, limit, offset):
    """Full-text search via FTS5, fall back to LIKE."""
    try:
        fts_sql = """
            SELECT hp.uniprot_id, hp.is_repeat, hp.related_ids, hp.uniprot_url, hp.fasta_url,
                   hp.hp_label, w.hp_label AS weka_hp, w.class_label,
                   w.c1_protein_family, w.c2_orthology, w.c3_interaction,
                   w.c4_bbh, w.c5_sorting_signal, w.c6_pseudogene, w.c7_homology,
                   uc.organism, uc.protein_name, uc.domains, uc.sequence_length
            FROM cache_fts f
            JOIN uniprot_cache uc ON uc.id = f.rowid
            JOIN hypo_proteins hp ON hp.uniprot_id = uc.uniprot_id
            LEFT JOIN weka_scores w ON w.hp_label = hp.hp_label
            WHERE cache_fts MATCH ?
            ORDER BY rank
            LIMIT ? OFFSET ?
        """
        rows = conn.execute(fts_sql, (q, limit, offset)).fetchall()
        if rows:
            total = conn.execute(
                "SELECT COUNT(*) FROM cache_fts WHERE cache_fts MATCH ?", (q,)
            ).fetchone()[0]
            return rows, total
    except Exception:
        pass

    # Fallback LIKE search
    pattern = f"%{q}%"
    sql = """
        SELECT hp.uniprot_id, hp.is_repeat, hp.related_ids, hp.uniprot_url, hp.fasta_url,
               hp.hp_label, w.hp_label AS weka_hp, w.class_label,
               w.c1_protein_family, w.c2_orthology, w.c3_interaction,
               w.c4_bbh, w.c5_sorting_signal, w.c6_pseudogene, w.c7_homology,
               uc.organism, uc.protein_name, uc.domains, uc.sequence_length
        FROM hypo_proteins hp
        LEFT JOIN uniprot_cache uc ON uc.uniprot_id = hp.uniprot_id
        LEFT JOIN weka_scores w ON w.hp_label = hp.hp_label
        WHERE hp.uniprot_id LIKE ?
           OR uc.organism LIKE ?
           OR uc.protein_name LIKE ?
           OR uc.domains LIKE ?
           OR hp.hp_label LIKE ?
        ORDER BY hp.uniprot_id
        LIMIT ? OFFSET ?
    """
    rows = conn.execute(sql, (pattern,)*5 + (limit, offset)).fetchall()
    total = conn.execute("""
        SELECT COUNT(*) FROM hypo_proteins hp
        LEFT JOIN uniprot_cache uc ON uc.uniprot_id = hp.uniprot_id
        WHERE hp.uniprot_id LIKE ? OR uc.organism LIKE ?
           OR uc.protein_name LIKE ? OR hp.hp_label LIKE ?
    """, (pattern,)*4).fetchone()[0]
    return rows, total


def _format_row(row, conn) -> dict:
    """Convert a SQLite row into a clean dict for the API response."""
    uid = row["uniprot_id"] if row["uniprot_id"] else None
    return {
        "uniprot_id":    uid,
        "hp_label":      row["weka_hp"] or row["hp_label"],
        "class_label":   row["class_label"],
        "class_text":    ("Pathogenic" if row["class_label"] == 1
                          else "Non-pathogenic" if row["class_label"] == 0
                          else "Unknown"),
        "organism":      row["organism"],
        "protein_name":  row["protein_name"],
        "domains":       row["domains"],
        "sequence_length": row["sequence_length"],
        "is_repeat":     bool(row["is_repeat"]),
        "uniprot_url":   row["uniprot_url"],
        "fasta_url":     row["fasta_url"],
        "scores": {
            "c1_protein_family": row["c1_protein_family"],
            "c2_orthology":      row["c2_orthology"],
            "c3_interaction":    row["c3_interaction"],
            "c4_bbh":            row["c4_bbh"],
            "c5_sorting_signal": row["c5_sorting_signal"],
            "c6_pseudogene":     row["c6_pseudogene"],
            "c7_homology":       row["c7_homology"],
        } if row["weka_hp"] else None,
    }
