"""
loader.py — Ingests all data files into the HypoBac SQLite database.
Same MD5 hash-tracking system as HoriGene — safe to call multiple times.
"""

import os
from app.core.config import WEKA_DIR, HYPO_DIR
from app.core.database import get_connection
from app.utils.parsers import (
    parse_weka_csv, parse_hypo3_xlsx, file_hash
)


# ── Internal helpers ──────────────────────────────────────────────────────────

def _is_new_or_changed(conn, filepath: str) -> tuple[bool, str]:
    h = file_hash(filepath)
    row = conn.execute(
        "SELECT file_hash FROM ingested_files WHERE filepath = ?", (filepath,)
    ).fetchone()
    if row is None:
        return True, h
    return row["file_hash"] != h, h


def _mark_ingested(conn, filepath: str, h: str):
    conn.execute("""
        INSERT INTO ingested_files (filepath, file_hash)
        VALUES (?, ?)
        ON CONFLICT(filepath) DO UPDATE
            SET file_hash   = excluded.file_hash,
                ingested_at = datetime('now')
    """, (filepath, h))


# ── Public API ────────────────────────────────────────────────────────────────

def load_all() -> dict:
    """
    Scan both data folders and ingest any new/changed files.
    Returns a summary dict.
    """
    summary = {
        "weka_rows":      0,
        "proteins_added": 0,
        "links_added":    0,
        "files_processed": [],
        "files_skipped":   [],
        "errors":          [],
    }

    conn = get_connection()
    try:
        _ingest_folder(conn, WEKA_DIR,  [".csv"],          _handle_weka,  summary)
        _ingest_folder(conn, HYPO_DIR,  [".xlsx", ".xls"], _handle_hypo3, summary)
        conn.commit()
    except Exception as e:
        conn.rollback()
        summary["errors"].append(str(e))
        print(f"[LOADER] Critical error: {e}")
    finally:
        conn.close()

    print(f"[LOADER] Done. {summary}")
    return summary


def check_for_new_files() -> dict:
    new_files     = []
    changed_files = []
    conn = get_connection()

    for folder in [WEKA_DIR, HYPO_DIR]:
        if not os.path.isdir(folder):
            continue
        for fname in os.listdir(folder):
            fpath = os.path.join(folder, fname)
            if not os.path.isfile(fpath):
                continue
            needs, _ = _is_new_or_changed(conn, fpath)
            if needs:
                existing = conn.execute(
                    "SELECT filepath FROM ingested_files WHERE filepath = ?", (fpath,)
                ).fetchone()
                (changed_files if existing else new_files).append(fpath)

    conn.close()
    return {
        "new_files":     new_files,
        "changed_files": changed_files,
        "has_updates":   bool(new_files or changed_files),
    }


# ── Folder scanner ────────────────────────────────────────────────────────────

def _ingest_folder(conn, folder, extensions, handler, summary):
    if not os.path.isdir(folder):
        print(f"[LOADER] Folder not found, skipping: {folder}")
        return

    for fname in sorted(os.listdir(folder)):
        fpath = os.path.join(folder, fname)
        if not os.path.isfile(fpath):
            continue
        if os.path.splitext(fname)[1].lower() not in extensions:
            continue

        needs, h = _is_new_or_changed(conn, fpath)
        if not needs:
            summary["files_skipped"].append(fname)
            continue

        try:
            handler(conn, fpath, summary)
            _mark_ingested(conn, fpath, h)
            summary["files_processed"].append(fname)
            print(f"[LOADER] Ingested: {fname}")
        except Exception as e:
            summary["errors"].append(f"{fname}: {e}")
            print(f"[LOADER] Error ingesting {fname}: {e}")


# ── Per-type handlers ─────────────────────────────────────────────────────────

def _handle_weka(conn, filepath, summary):
    rows = parse_weka_csv(filepath)
    for r in rows:
        conn.execute("""
            INSERT INTO weka_scores
                (hp_label, c1_protein_family, c2_orthology, c3_interaction,
                 c4_bbh, c5_sorting_signal, c6_pseudogene, c7_homology,
                 class_label, source_file)
            VALUES
                (:hp_label, :c1_protein_family, :c2_orthology, :c3_interaction,
                 :c4_bbh, :c5_sorting_signal, :c6_pseudogene, :c7_homology,
                 :class_label, :source_file)
            ON CONFLICT(hp_label) DO UPDATE SET
                c1_protein_family = excluded.c1_protein_family,
                c2_orthology      = excluded.c2_orthology,
                c3_interaction    = excluded.c3_interaction,
                c4_bbh            = excluded.c4_bbh,
                c5_sorting_signal = excluded.c5_sorting_signal,
                c6_pseudogene     = excluded.c6_pseudogene,
                c7_homology       = excluded.c7_homology,
                class_label       = excluded.class_label,
                source_file       = excluded.source_file
        """, r)
        summary["weka_rows"] += 1


def _handle_hypo3(conn, filepath, summary):
    data = parse_hypo3_xlsx(filepath)

    # Build a URL lookup from Sheet 2 (uniprot_id → urls)
    url_map = {}
    for lnk in data.get("links", []):
        url_map[lnk["uniprot_id"]] = lnk

    # Insert proteins from Sheet 1, enriched with URLs from Sheet 2
    for p in data.get("proteins", []):
        urls = url_map.get(p["uniprot_id"], {})
        conn.execute("""
            INSERT INTO hypo_proteins
                (uniprot_id, is_repeat, related_ids, uniprot_url, fasta_url, source_file)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(uniprot_id) DO UPDATE SET
                is_repeat   = excluded.is_repeat,
                related_ids = excluded.related_ids,
                uniprot_url = COALESCE(excluded.uniprot_url, hypo_proteins.uniprot_url),
                fasta_url   = COALESCE(excluded.fasta_url,   hypo_proteins.fasta_url),
                source_file = excluded.source_file
        """, (
            p["uniprot_id"],
            p["is_repeat"],
            p["related_ids"],
            urls.get("uniprot_url", f"https://rest.uniprot.org/uniprotkb/{p['uniprot_id']}.txt"),
            urls.get("fasta_url",   f"https://rest.uniprot.org/uniprotkb/{p['uniprot_id']}.fasta"),
            p["source_file"],
        ))
        summary["proteins_added"] += 1

    # Insert any Sheet 2 IDs that aren't already in hypo_proteins
    for lnk in data.get("links", []):
        existing = conn.execute(
            "SELECT id FROM hypo_proteins WHERE uniprot_id = ?", (lnk["uniprot_id"],)
        ).fetchone()
        if not existing:
            conn.execute("""
                INSERT INTO hypo_proteins (uniprot_id, uniprot_url, fasta_url, source_file)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(uniprot_id) DO NOTHING
            """, (lnk["uniprot_id"], lnk["uniprot_url"], lnk["fasta_url"], lnk["source_file"]))
            summary["links_added"] += 1

    # Sheet 3 — same pattern, handles NCBI IDs when they arrive
    for entry in data.get("ncbi", []):
        uid = entry.get("uniprot_id") or entry.get("ncbi_id", "")
        if not uid:
            continue
        conn.execute("""
            INSERT INTO hypo_proteins (uniprot_id, uniprot_url, fasta_url, source_file)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(uniprot_id) DO NOTHING
        """, (uid, entry.get("uniprot_url",""), entry.get("fasta_url",""), entry["source_file"]))
        summary["proteins_added"] += 1
